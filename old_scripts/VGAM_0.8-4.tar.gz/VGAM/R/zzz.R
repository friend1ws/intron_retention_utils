# These functions are
# Copyright (C) 1998-2011 T.W. Yee, University of Auckland.
# All rights reserved.



.First.lib <- function(lib, pkg) {
    library.dynam("VGAM", pkg, lib) 
}




